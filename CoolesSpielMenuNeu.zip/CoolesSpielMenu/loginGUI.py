# -*- coding: cp1252 -*-
#Datum:     04.01.2017
#Autor:     Kerim Merodivc
#Version:   2.0

"""
Dieses Skript ist eine GUI f�r das Login - Fenster, geschrieben in Python mit Pygame.
Man kann kann einem Raum joinen und ein Raum hosten.
Desweiteren gibt es ein Entry, wo man den Spielernamen eingeben kann.

"""

import sys

import pygame
from pygame.locals import *

import border
import button
import entry
import label

"""

"""

pygame.init()

screen = pygame.display.set_mode((400,200),0,32)
pygame.mouse.set_visible(1)
pygame.key.set_repeat(1,50)
caption = "Cooles Spiel"
pygame.display.set_caption(caption)

background = pygame.Surface((400,200))
background.fill((199,199,199))

def main_login():

    bo = border.RoundedBorder((5,5),(5,5),(87, 87, 87), 10)
    bo2 = border.RoundedBorder((1,1),(1,1),(87, 87, 87), 2)
    bo3= border.ColoredBorder(1, 1, (87, 87, 87))
    b1 = button.Button(50, 75, 100, 50, "Join Room", callback = join_room).setBackground((87, 87, 87)).setForeground((255, 255, 255)).setBorder(bo)
    b2 = button.Button(250, 75, 100, 50, "Host Server", callback = host_server).setBackground((87, 87, 87)).setForeground((255, 255, 255)).setBorder(bo)
    b3 = button.Button(375, 3, 20, 20, "?", callback = help_bu).setBackground((87, 87, 87)).setForeground((255, 255, 255)).setBorder(bo2)
    b4 = button.Button(347, 3, 20, 20, "!", callback = info_bu).setBackground((87, 87, 87)).setForeground((255, 255, 255)).setBorder(bo2)
    e = entry.Entry(150, 165, 100, 15, "         n a m e").setBackground((199, 199, 199)).setForeground((87, 87, 87)).setBorder(bo3)
    l = label.Label(135, 145, 135, 10, "Enter your name here:").setBackground((199, 199, 199)).setForeground((87, 87, 87))
    l2 = label.Label(135, 35, 135, 10, "Cooles Spiel").setBackground((199, 199, 199)).setForeground((87, 87, 87))

    group = pygame.sprite.LayeredDirty([b1,b2,b3,b4,e,l,l2])

    group.update()
    group.draw(screen, background)
    going = True
    while going:
        #Handle Input Events#
        for event in pygame.event.get():
            if event.type == QUIT:
                going = False
            group.update(event)
        group.draw(screen, background)
        pygame.display.update()
        pygame.time.wait(100)
    pygame.quit()
    sys.exit()


def join_room():

    bo = border.RoundedBorder((5,5),(5,5),(87,87,87),5)
    bo2 = border.RoundedBorder((1,1),(1,1),(87, 87, 87), 2)
    b = button.Button(20,20,50,10,"Zur�ck", callback=back).setBackground((87,87,87)).setForeground((255,255,255)).setBorder(bo)
    e = entry.Entry(150,18,100,15, "          suche").setBackground((199,199,199)).setForeground((87,87,87)).setBorder(bo2)

    group = pygame.sprite.LayeredDirty([b,e])

    group.update()
    group.draw(screen, background)
    going = True
    while going:
        #Handle Input Events#
        for event in pygame.event.get():
            if event.type == QUIT:
                going = False
            group.update(event)
        group.draw(screen, background)
        pygame.display.update()
        pygame.time.wait(100)
    pygame.quit()
    sys.exit()


def host_server():

    """
    Welche Einstellungen soll man als Host in der GUI haben ?
    Spiel starten; MapAuswahl; Spielerzahl
    """
    bo = border.RoundedBorder((5, 5), (5, 5), (87, 87, 87), 5)
    b = button.Button(20, 20, 50, 10, "Zur�ck", callback=back).setBackground((87, 87, 87)).setForeground((255, 255, 255)).setBorder(bo)
    b2 = button.Button(150, 165, 100, 15, "Spiel starten", callback=spiel_start).setBackground((87, 87, 87)).setForeground((255, 255, 255)).setBorder(bo)
    l = label.Label(5, 60, 135, 10, "Karte:").setBackground((199, 199, 199)).setForeground((87, 87, 87))
    l2 = label.Label(27, 120, 135, 10, "Spieleranzahl").setBackground((199, 199, 199)).setForeground((87, 87, 87))
    group = pygame.sprite.LayeredDirty([b,b2,l,l2])

    going = True
    while going:
        # Handle Input Events#
        for event in pygame.event.get():
            if event.type == QUIT:
                going = False
            group.update(event)
        group.draw(screen, background)
        pygame.display.update()
        pygame.time.wait(100)
    pygame.quit()
    sys.exit()


def help_bu():
    pass


def info_bu():
    pass


def spiel_start():
    pass


def back():
    main_login()

if __name__ == "__main__":
    main_login()
