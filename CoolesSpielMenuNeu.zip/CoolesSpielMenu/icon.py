# -*- coding: cp1252 -*-

import pygame
import widget


class Icon(widget.Widget):
    
    def __init__(self, x, y, width, height, surface):
        """
        Initialisation of a Widget

        parameters:     int x-coordinate of the Widget (left)
                        int y-coordinate of the Widget (top)
                        int width of the Widget
                        int height of the Widget
        return values:  -
        """
        widget.Widget.__init__(self, x, y, width, height)
        self.image              = surface

    def _getAppearance(self, *args):
        """
        Return the underlying Widget's appearance;
        basic implementation of background-coloring

        private function

        parameters:     tuple arguments for the update (first argument should be an instance pygame.event.Event)
        return values:  pygame.Surface the underlying Widget's appearance
        """
        return self.image
